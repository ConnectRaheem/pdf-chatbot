"""
app.py
------
Streamlit frontend for the RAG PDF Chatbot.

Client pitch: "Upload any PDF -- a contract, manual, report, policy
document -- and get instant, grounded, cited answers instead of
manually searching through pages."

Run locally:
    streamlit run app.py

Deploy free:
    https://share.streamlit.io  (Streamlit Community Cloud)
See README.md for full deployment steps.
"""

import os
import tempfile

import streamlit as st
from rag_engine import PDFChatEngine

st.set_page_config(
    page_title="DocChat AI — Talk to Your Documents",
    page_icon="📄",
    layout="wide",
)

# --------------------------------------------------------------------- #
# Sidebar — branding, uploader, and controls
# --------------------------------------------------------------------- #
with st.sidebar:
    st.markdown("## 📄 DocChat AI")
    st.caption("Retrieval-Augmented Generation demo — built by CogniticSolutions")

    st.markdown("---")

    groq_key_input = st.text_input(
        "Groq API key",
        type="password",
        value=os.environ.get("GROQ_API_KEY", ""),
        help="Get a free key at console.groq.com. Not stored anywhere.",
    )

    uploaded_files = st.file_uploader(
        "Upload one or more PDFs",
        type=["pdf"],
        accept_multiple_files=True,
    )

    process_clicked = st.button("Process documents", type="primary", use_container_width=True)

    st.markdown("---")
    if st.button("🗑️ Clear session", use_container_width=True):
        st.session_state.clear()
        st.rerun()

    st.markdown("---")
    st.caption(
        "**Stack:** LangChain · Groq (Llama 3.3 70B) · FAISS · "
        "HuggingFace embeddings · Streamlit"
    )

# --------------------------------------------------------------------- #
# Session state
# --------------------------------------------------------------------- #
if "engine" not in st.session_state:
    st.session_state.engine = None
if "messages" not in st.session_state:
    st.session_state.messages = []  # list of dicts: role, content, sources

# --------------------------------------------------------------------- #
# Process uploaded PDFs
# --------------------------------------------------------------------- #
if process_clicked:
    if not groq_key_input:
        st.sidebar.error("Add a Groq API key first.")
    elif not uploaded_files:
        st.sidebar.error("Upload at least one PDF first.")
    else:
        with st.spinner("Reading and indexing document(s)..."):
            engine = st.session_state.engine or PDFChatEngine(groq_api_key=groq_key_input)
            tmp_paths = []
            for f in uploaded_files:
                tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
                tmp.write(f.read())
                tmp.close()
                tmp_paths.append(tmp.name)

            chunk_count = engine.add_pdfs(tmp_paths)
            st.session_state.engine = engine

        st.sidebar.success(f"Indexed {chunk_count} chunks from {len(uploaded_files)} file(s).")

# --------------------------------------------------------------------- #
# Main chat area
# --------------------------------------------------------------------- #
st.title("Chat with your documents")

if not st.session_state.engine or not st.session_state.engine.is_ready:
    st.info(
        "👈 Upload a PDF in the sidebar, add a Groq API key, and click "
        "**Process documents** to get started. Try a policy document, "
        "a contract, a research paper, or a product manual."
    )
else:
    files_label = ", ".join(st.session_state.engine.indexed_files)
    st.caption(f"📚 Ready — indexed: {files_label}")

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            with st.expander("View sources"):
                for i, doc in enumerate(msg["sources"], start=1):
                    page = doc.metadata.get("page", 0) + 1
                    src = doc.metadata.get("source_file", "document")
                    st.markdown(f"**{i}. {src} — page {page}**")
                    st.caption(doc.page_content[:400] + "...")

question = st.chat_input("Ask a question about your document(s)...")

if question:
    if not st.session_state.engine or not st.session_state.engine.is_ready:
        st.warning("Please upload and process a PDF first.")
    else:
        st.session_state.messages.append({"role": "user", "content": question})
        with st.chat_message("user"):
            st.markdown(question)

        history = [
            (m["content"], st.session_state.messages[i + 1]["content"])
            for i, m in enumerate(st.session_state.messages[:-1])
            if m["role"] == "user" and i + 1 < len(st.session_state.messages) - 1
        ]

        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    result = st.session_state.engine.ask(question, chat_history=history)
                    st.markdown(result.answer)
                    if result.sources:
                        with st.expander("View sources"):
                            for i, doc in enumerate(result.sources, start=1):
                                page = doc.metadata.get("page", 0) + 1
                                src = doc.metadata.get("source_file", "document")
                                st.markdown(f"**{i}. {src} — page {page}**")
                                st.caption(doc.page_content[:400] + "...")
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": result.answer,
                        "sources": result.sources,
                    })
                except Exception as e:
                    st.error(f"Something went wrong: {e}")
